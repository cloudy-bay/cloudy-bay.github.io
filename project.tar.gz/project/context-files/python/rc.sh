cp /tmp/context-files/pip.conf /etc/pip.conf

VENV_DIR=/tmp/assignments/.venv
if test -d "$VENV_DIR"; then
    rm -rf "$VENV_DIR"
fi
python3 -m venv $VENV_DIR
source $VENV_DIR/bin/activate

pip3 install pip --upgrade
pip3 install -r /tmp/context-files/requirements.txt

python3 /tmp/assignments/src/app.py > /tmp/result/a.out